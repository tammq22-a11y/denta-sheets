// Public Supabase project settings. Never place a service_role/secret key here.
window.DENTA_SUPABASE = {
  url: 'https://xbxvtegoqkfjwruyqswd.supabase.co',
  publishableKey: 'sb_publishable_J1lU2J-G4vfqMCZXsRCdcA_3QL2QXZt'
};
