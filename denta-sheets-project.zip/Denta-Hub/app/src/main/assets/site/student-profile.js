/* Denta Hub student registration: cloud insert only; clinical cases remain local. */
(()=>{
  const KEY='denta-student-profile-v1', SYNC='denta-student-profile-supabase-v1';
  const levels=['سنة رابعة','سنة خامسة','الامتياز','أخرى'];
  const cfg=window.DENTA_SUPABASE||{};
  const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){return null}};
  const valid=p=>p&&typeof p.name==='string'&&p.name.trim().length>=2&&levels.includes(p.level);
  const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const isSynced=()=>localStorage.getItem(SYNC)==='yes';
  async function sendToSupabase(profile){
    if(!cfg.url||!cfg.publishableKey) throw new Error('إعداد الاتصال بقاعدة البيانات غير مكتمل.');
    const response=await fetch(cfg.url.replace(/\/$/,'')+'/rest/v1/students',{
      method:'POST',
      headers:{'Content-Type':'application/json','apikey':cfg.publishableKey,'Authorization':'Bearer '+cfg.publishableKey,'Prefer':'return=minimal'},
      body:JSON.stringify({name:profile.name.trim(),level:profile.level})
    });
    if(!response.ok){let detail='';try{const data=await response.json();detail=data.message||data.details||data.hint||''}catch(_){};throw new Error(detail||('تعذر حفظ التسجيل (HTTP '+response.status+').'))}
  }
  const build=(initial)=>{
    document.getElementById('student-gate')?.remove();
    const layer=document.createElement('div');layer.className='student-gate';layer.id='student-gate';
    layer.innerHTML=`<section class="student-gate-card" role="dialog" aria-modal="true" aria-labelledby="student-gate-title"><img src="denta-logo.png" alt="دِنتــا" class="student-gate-logo"><h2 id="student-gate-title">بيانات الطالب</h2><p>سجّل اسمك ومستواك الدراسي للمتابعة. تُرسل هذه البيانات فقط إلى قاعدة تسجيل الطلاب.</p><form id="student-profile-form"><label for="student-name">الاسم</label><input id="student-name" name="name" type="text" autocomplete="name" maxlength="70" placeholder="اكتب اسمك الكامل" required><label for="student-level">المستوى الدراسي</label><select id="student-level" name="level" required><option value="">اختر مستواك الدراسي</option>${levels.map(x=>`<option value="${x}">${x}</option>`).join('')}</select><p class="student-gate-error" id="student-gate-error" aria-live="polite"></p><button type="submit" id="student-submit">حفظ ومتابعة</button></form><small>يلزم الاتصال بالإنترنت لإتمام التسجيل أول مرة. الحالات السريرية وصورها لا تُرفع إلى السحابة.</small></section>`;
    document.body.appendChild(layer);
    const form=layer.querySelector('form');
    if(initial){form.elements.namedItem('name').value=initial.name||'';form.elements.namedItem('level').value=initial.level||'';}
    form.addEventListener('submit',async e=>{
      e.preventDefault();const name=form.elements.namedItem('name').value.trim(),level=form.elements.namedItem('level').value;
      const error=layer.querySelector('#student-gate-error'),button=layer.querySelector('#student-submit');
      if(name.length<2||!levels.includes(level)){error.textContent='يرجى كتابة اسم صحيح واختيار المستوى.';return}
      button.disabled=true;button.textContent='جارٍ تسجيل البيانات…';error.textContent='';
      try{await sendToSupabase({name,level});localStorage.setItem(KEY,JSON.stringify({name,level}));localStorage.setItem(SYNC,'yes');layer.remove();showGreeting({name,level});}
      catch(err){error.textContent=(err&&err.message)||'حدث خطأ أثناء التسجيل. تحقق من الإنترنت وحاول مجدداً.';button.disabled=false;button.textContent='إعادة المحاولة';}
    });
    layer.querySelector('#student-name').focus();
  };
  function showGreeting(p){const hero=document.querySelector('.hero-card');if(!hero||document.getElementById('student-greeting'))return;const box=document.createElement('div');box.id='student-greeting';box.className='student-greeting';box.innerHTML=`<span>مرحباً، ${escapeHtml(p.name)}</span><small>${escapeHtml(p.level)}</small><button type="button" id="edit-student-profile">تعديل</button>`;hero.appendChild(box);box.querySelector('button').addEventListener('click',()=>{localStorage.removeItem(SYNC);build(p);});}
  const profile=read();
  const start=()=>{if(valid(profile)&&isSynced())showGreeting(profile);else build(valid(profile)?profile:null)};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
