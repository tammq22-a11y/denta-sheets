/* Required local student profile for DenTA */
(()=>{
  const KEY='denta-student-profile-v1';
  const levels=['سنة رابعة','سنة خامسة','الامتياز','أخرى'];
  const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){return null}};
  const valid=p=>p&&typeof p.name==='string'&&p.name.trim().length>=2&&levels.includes(p.level);
  const build=()=>{
    const layer=document.createElement('div');layer.className='student-gate';layer.id='student-gate';layer.innerHTML=`<section class="student-gate-card" role="dialog" aria-modal="true" aria-labelledby="student-gate-title"><img src="denta-logo.png" alt="دِنتـــا" class="student-gate-logo"><h2 id="student-gate-title">بيانات الطالب</h2><p>قبل استخدام التطبيق، أدخل اسمك ومستواك الدراسي.</p><form id="student-profile-form"><label for="student-name">الاسم</label><input id="student-name" name="name" type="text" autocomplete="name" maxlength="70" placeholder="اكتب اسمك الكامل" required><label for="student-level">المستوى الدراسي</label><select id="student-level" name="level" required><option value="">اختر مستواك الدراسي</option>${levels.map(x=>`<option value="${x}">${x}</option>`).join('')}</select><p class="student-gate-error" id="student-gate-error" aria-live="polite"></p><button type="submit">حفظ ومتابعة</button></form><small>تُحفظ البيانات على هذا الجهاز فقط.</small></section>`;
    document.body.appendChild(layer);
    const form=layer.querySelector('form');form.addEventListener('submit',e=>{e.preventDefault();const name=form.elements.namedItem('name').value.trim(),level=form.elements.namedItem('level').value;if(name.length<2||!levels.includes(level)){layer.querySelector('#student-gate-error').textContent='يرجى كتابة اسم صحيح واختيار المستوى.';return}localStorage.setItem(KEY,JSON.stringify({name,level}));layer.remove();showGreeting({name,level});});
    layer.querySelector('#student-name').focus();
  };
  function showGreeting(p){const hero=document.querySelector('.hero-card');if(!hero||document.getElementById('student-greeting'))return;const box=document.createElement('div');box.id='student-greeting';box.className='student-greeting';box.innerHTML=`<span>مرحباً، ${escapeHtml(p.name)}</span><small>${escapeHtml(p.level)}</small><button type="button" id="edit-student-profile">تعديل</button>`;hero.appendChild(box);box.querySelector('button').addEventListener('click',()=>{localStorage.removeItem(KEY);build();});}
  function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  const profile=read();if(valid(profile)){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>showGreeting(profile));else showGreeting(profile);}else{if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',build);else build();}
})();
