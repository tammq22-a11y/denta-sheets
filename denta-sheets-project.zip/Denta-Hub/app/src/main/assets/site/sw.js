const CACHE='denta-sheets-v4-contrast';
const CORE=[
  './','./index.html','./app.html','./clinical-cases.html','./clinical-cases.css','./clinical-cases.js','./case-sheets.html','./products.html','./about.html','./contact.html',
  './assets/css/style.css','./assets/js/app.js','./assets/js/products-data.js',
  './case-sheets/case-sheets.css','./case-sheets/case-sheets.js',
  './1.png','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'
];
self.addEventListener('install',event=>{
  event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch',event=>{
  const request=event.request;
  const url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin)return;
  event.respondWith(caches.match(request).then(cached=>{
    if(cached)return cached;
    return fetch(request).then(response=>{
      if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(request,copy));}
      return response;
    }).catch(()=>request.mode==='navigate'?caches.match('./app.html'):Response.error());
  }));
});
