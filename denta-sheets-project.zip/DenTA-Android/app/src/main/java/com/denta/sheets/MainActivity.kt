package com.denta.sheets

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.net.Uri
import android.print.PrintManager
import android.print.PrintAttributes
import android.webkit.JavascriptInterface
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var printWebView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 18, 31)
        window.navigationBarColor = Color.rgb(7, 18, 31)

        val root = FrameLayout(this)
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress, FrameLayout.LayoutParams(-1, 7))
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
        }
        webView.setBackgroundColor(Color.rgb(7, 18, 31))
        webView.addJavascriptInterface(NativeBridge(), "DenTANative")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "file" && uri.toString().startsWith("file:///android_asset/")) return false
                if (uri.scheme == "https" || uri.scheme == "http" || uri.scheme == "mailto" || uri.scheme == "tel") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: Exception) { false }
                }
                return false
            }
        }
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/site/app.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }


    inner class NativeBridge {
        @JavascriptInterface
        fun printHtml(html: String, jobName: String) {
            runOnUiThread {
                try {
                    printWebView?.destroy()
                    val printer = WebView(this@MainActivity)
                    printWebView = printer
                    printer.settings.javaScriptEnabled = true
                    printer.settings.domStorageEnabled = true
                    printer.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            Handler(Looper.getMainLooper()).postDelayed({
                                try {
                                    val manager = getSystemService(PRINT_SERVICE) as PrintManager
                                    val adapter = printer.createPrintDocumentAdapter(jobName.take(48))
                                    manager.print(jobName.take(48), adapter, PrintAttributes.Builder()
                                        .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                        .setResolution(PrintAttributes.Resolution("denta", "DenTA PDF", 300, 300))
                                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                        .build())
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(this@MainActivity, "تعذر فتح حفظ PDF: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }, 500)
                        }
                    }
                    printer.loadDataWithBaseURL("file:///android_asset/site/", html, "text/html", "UTF-8", null)
                } catch (e: Exception) {
                    android.widget.Toast.makeText(this@MainActivity, "تعذر تجهيز PDF: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        printWebView?.destroy()
        super.onDestroy()
    }
}
