package com.denta.sheets

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.provider.MediaStore
import android.content.ContentValues
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.net.Uri
import android.print.PrintManager
import android.print.PrintAttributes
import android.webkit.JavascriptInterface
import android.os.Handler
import android.os.Looper

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar
    private var printWebView: WebView? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingCameraUri: Uri? = null
    private val FILE_CHOOSER_REQUEST = 4102

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 18, 31)
        window.navigationBarColor = Color.rgb(7, 18, 31)

        val root = FrameLayout(this)
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progress.max = 100
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress, FrameLayout.LayoutParams(-1, 7))
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            mediaPlaybackRequiresUserGesture = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
        }
        webView.setBackgroundColor(Color.rgb(7, 18, 31))
        webView.addJavascriptInterface(NativeBridge(), "DenTANative")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                val pickIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                try {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "DentaHub_" + System.currentTimeMillis() + ".jpg")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    }
                    pendingCameraUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (pendingCameraUri != null) cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri)
                    val chooser = Intent.createChooser(pickIntent, "اختر صورة الحالة")
                    if (pendingCameraUri != null) chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, arrayOf(cameraIntent))
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST)
                    return true
                } catch (_: Exception) {
                    fileChooserCallback = null
                    return false
                }
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "file" && uri.toString().startsWith("file:///android_asset/")) return false
                if (uri.scheme == "https" || uri.scheme == "http" || uri.scheme == "mailto" || uri.scheme == "tel") {
                    return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: Exception) { false }
                }
                return false
            }
        }
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/site/app.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }



    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val callback = fileChooserCallback ?: return
            fileChooserCallback = null
            val result: Array<Uri>? = if (resultCode == Activity.RESULT_OK) {
                val selected = mutableListOf<Uri>()
                val clip = data?.clipData
                if (clip != null && clip.itemCount > 0) {
                    for (i in 0 until clip.itemCount) clip.getItemAt(i)?.uri?.let { selected.add(it) }
                } else {
                    (data?.data ?: pendingCameraUri)?.let { selected.add(it) }
                }
                val cameraUri = pendingCameraUri
                val normalized = selected.distinct().mapNotNull { uri ->
                    if (cameraUri != null && uri == cameraUri) uri else normalizeGalleryImage(uri)
                }
                if (normalized.isNotEmpty()) normalized.toTypedArray() else {
                    if (selected.isNotEmpty()) runOnUiThread { android.widget.Toast.makeText(this, "تعذر قراءة الصورة المختارة. جرّب JPG أو PNG.", android.widget.Toast.LENGTH_LONG).show() }
                    null
                }
            } else null
            if ((result == null || result.none { it == pendingCameraUri }) && pendingCameraUri != null) {
                try { contentResolver.delete(pendingCameraUri!!, null, null) } catch (_: Exception) {}
            }
            pendingCameraUri = null
            callback.onReceiveValue(result)
        }
    }


    /** Convert gallery formats (including HEIC where Android supports it) to WebView-safe JPEGs.
     * Files are kept in the app cache; clinical photos remain local and are not uploaded. */
    private fun normalizeGalleryImage(uri: Uri): Uri? {
        return try {
            val bitmap: Bitmap = if (Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    val w = info.size.width
                    val h = info.size.height
                    val scale = minOf(1.0, 2048.0 / maxOf(w, h))
                    decoder.setTargetSize((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1))
                    decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
                    decoder.isMutableRequired = false
                }
            } else {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                val sample = calculateInSampleSize(bounds, 2048, 2048)
                val options = BitmapFactory.Options().apply { inSampleSize = sample }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
                    ?: return null
            }
            val outDir = File(cacheDir, "clinical-gallery").apply { mkdirs() }
            val out = File(outDir, "gallery_${System.currentTimeMillis()}_${(0..9999).random()}.jpg")
            FileOutputStream(out).use { stream ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 90, stream)) throw IllegalStateException("تعذر تحويل الصورة")
                stream.flush()
            }
            if (!bitmap.isRecycled) bitmap.recycle()
            Uri.fromFile(out)
        } catch (_: Exception) { null }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        var sample = 1
        val height = options.outHeight
        val width = options.outWidth
        while (height / sample > reqHeight || width / sample > reqWidth) sample *= 2
        return sample.coerceAtLeast(1)
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun printHtml(html: String, jobName: String) {
            runOnUiThread {
                try {
                    printWebView?.destroy()
                    val printer = WebView(this@MainActivity)
                    printWebView = printer
                    printer.settings.javaScriptEnabled = true
                    printer.settings.domStorageEnabled = true
                    printer.webViewClient = object : WebViewClient() {
                        override fun onPageFinished(view: WebView?, url: String?) {
                            printer.settings.loadsImagesAutomatically = true
                            printer.settings.blockNetworkImage = false
                            printer.settings.allowFileAccess = true
                            printer.settings.allowContentAccess = true
                            // Wait for embedded photos and logo to finish decoding before creating the print adapter.
                            val startedAt = System.currentTimeMillis()
                            fun waitForImages() {
                                printer.evaluateJavascript(
                                    "(function(){var a=[].slice.call(document.images);return a.every(function(i){return i.complete && i.naturalWidth>0})})()"
                                ) { result ->
                                    val ready = result == "true"
                                    if (!ready && System.currentTimeMillis() - startedAt < 15000) {
                                        Handler(Looper.getMainLooper()).postDelayed({ waitForImages() }, 250)
                                    } else {
                                        Handler(Looper.getMainLooper()).postDelayed({
                                            try {
                                                val manager = getSystemService(PRINT_SERVICE) as PrintManager
                                                val adapter = printer.createPrintDocumentAdapter(jobName.take(48))
                                                manager.print(jobName.take(48), adapter, PrintAttributes.Builder()
                                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                                    .setResolution(PrintAttributes.Resolution("denta", "DenTA PDF", 300, 300))
                                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                                    .build())
                                            } catch (e: Exception) {
                                                android.widget.Toast.makeText(this@MainActivity, "تعذر فتح حفظ PDF: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                                            }
                                        }, 400)
                                    }
                                }
                            }
                            Handler(Looper.getMainLooper()).postDelayed({ waitForImages() }, 250)
                        }
                    }
                    printer.loadDataWithBaseURL("file:///android_asset/site/", html, "text/html", "UTF-8", null)
                } catch (e: Exception) {
                    android.widget.Toast.makeText(this@MainActivity, "تعذر تجهيز PDF: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        fileChooserCallback?.onReceiveValue(null)
        fileChooserCallback = null
        if (::webView.isInitialized) webView.destroy()
        printWebView?.destroy()
        super.onDestroy()
    }
}
